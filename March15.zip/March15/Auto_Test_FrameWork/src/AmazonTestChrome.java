import java.awt.Desktop;
import java.io.File; 
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.testng.Assert;
import org.testng.annotations.*;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.support.ui.Select;

public class AmazonTestChrome {
	private WebDriver driver;
	public static Logger logger = Logger.getLogger(ScreenShotDataProvider.class);
	static InputStream pathStream = AmazonTestChrome.class.getClassLoader().getResourceAsStream("SetPath.properties");
	InputStream emailStream = AmazonTestChrome.class.getClassLoader().getResourceAsStream("Email.properties");
	public static String[][] getExcelData() throws Exception {
		String[][] arrayExcelData = null;
		try {
			String FilePath = "C:\\NPU Studies\\CS595\\DataProvider.xlsx";
			// Open the Excel file
			FileInputStream ExcelFile = new FileInputStream(FilePath);
			System.out.print(ExcelFile);
			XSSFWorkbook ExcelWBook = new XSSFWorkbook(ExcelFile);
			XSSFSheet Sheet1 = ExcelWBook.getSheetAt(0);
			int totalNoOfRows = Sheet1.getPhysicalNumberOfRows();
			int totalNoOfCols = 2;
			arrayExcelData = new String[totalNoOfRows][totalNoOfCols];
			for (int i = 0; i < totalNoOfRows; i++)
				for (int j = 0; j <= 1; j++) {
					arrayExcelData[i][j] = Sheet1.getRow(i).getCell(j).getStringCellValue();
					System.out.print(arrayExcelData[i][j]);
				}
			ExcelWBook.close();
			return arrayExcelData;
		} catch (Exception e) {
			throw (e);

		}
	}

	static void captureScreenshot(WebDriver adriver) {
		File src = ((TakesScreenshot) adriver).getScreenshotAs(OutputType.FILE);
		try {
			Properties PathProperties = new Properties();
			String ssfile = PathProperties.getProperty("SSFile");
			FileUtils.copyFile(src, new File(ssfile + System.currentTimeMillis() + ".png"));
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			logger.info("\n\n" + e.getMessage());
		}

	}

/*@BeforeTest
//
public void urldriver() throws IOException {
Properties PathProperties = new Properties();
	PathProperties.load(pathStream);
	String DriverPath = PathProperties.getProperty("ChromeDrivePath");
	System.setProperty("webdriver.chrome.driver", DriverPath);
	WebDriver driver = new ChromeDriver();
	String baseURl = "https://www.amazon.com/";
	driver.get(baseURl);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
}*/

	// Data Provider
	@DataProvider(name = "excelData")
	
	public Object[][] loginData() throws Exception {
		Object[][] arrayObject = new Object[1][2];
		for (int i = 0; i < 1; i++) {
			for (int j = 0; j < 1; j++) {
				arrayObject = getExcelData();
			}
		}
		return arrayObject;
	}

	@DataProvider(name = "data")
	public static Object[][] getData(Method name) {
		Object[][] obj = null;

		if (name.getName().equalsIgnoreCase("keyWordSearching1")) {
			obj = new Object[3][1];

			obj[0][0] = "car";
			obj[1][0] = "amazon echo";
			obj[2][0] = "apple watch";
		}

		if (name.getName().equalsIgnoreCase("keyWordSearching")) {
			obj = new Object[1][1];
			obj[0][0] = "Dell laptops";
		}
		return obj;
	}

	@Test(dataProvider = "data")
	public void keyWordSearching(String keyword) throws IOException {
		try {	
			Properties PathProperties = new Properties();
			PathProperties.load(pathStream);
			String DriverPath = PathProperties.getProperty("ChromeDrivePath");
			System.setProperty("webdriver.chrome.driver", DriverPath);
			WebDriver driver = new ChromeDriver();
			String baseURl = "https://www.amazon.com/";
			driver.get(baseURl);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			driver.findElement(By.id("twotabsearchtextbox")).sendKeys(keyword);
			driver.findElement(By.xpath(".//*[@id='nav-search']/form/div[2]/div/input")).click();
			String ActualValue = driver.findElement(By.cssSelector(".a-color-state.a-text-bold")).getText();
			String expectedValue = keyword;
			ActualValue = ActualValue.replace("\"", "");
			Assert.assertTrue(expectedValue.equals(ActualValue), "Values matched");
			logger.info("Asserting first test case here");
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			driver.close();
			} catch (Exception e) {
			logger.info("\n\n" + e.getMessage());			
		}
	}
	@Test(dataProvider = "excelData")
	public void logInTest(String login, String password) throws IOException {
		try 
		{
			Properties PathProperties = new Properties();
			PathProperties.load(pathStream);
			String DriverPath = PathProperties.getProperty("ChromeDrivePath");
			System.setProperty("webdriver.chrome.driver", DriverPath);
			WebDriver driver = new ChromeDriver();
			String baseURl = "https://www.amazon.com/";
			driver.get(baseURl);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

			driver.findElement(By.xpath(".//*[@id='nav-link-accountList']/span[1]")).click();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			driver.findElement(By.xpath(".//*[@id='ap_email']")).sendKeys(login);
			driver.findElement(By.xpath(".//*[@id='ap_password']")).sendKeys(password);
			driver.findElement(By.xpath(".//*[@id='signInSubmit']")).click();
			driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			boolean titleTextfield = driver.findElement(By.xpath(".//*[@id='auth-warning-message-box']/div"))
					.isDisplayed();
			Assert.assertTrue(titleTextfield, "Title text field present which is not expected");
			driver.close();
		} catch (Exception e) { 
			logger.info("\n\n" + e.getMessage());
			
		}
	}

	@Test
	public void amazonMainPageTest() {
		try {
			Properties PathProperties = new Properties();
			PathProperties.load(pathStream);
			String DriverPath = PathProperties.getProperty("ChromeDrivePath");
			System.setProperty("webdriver.chrome.driver", DriverPath);
			WebDriver driver = new ChromeDriver();
			String baseURl = "https://www.amazon.com/";
			driver.get(baseURl);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			String expectedTitle = "Amazon.com: Online Shopping for Electronics, Apparel, Computers, Books, DVDs & more";
			String actualTitle = driver.getTitle();
			Assert.assertEquals(expectedTitle, actualTitle);
			AmazonTestChrome.captureScreenshot(driver);
			driver.close();

		} catch (Exception e) {
			logger.info("\n\n" + e.getMessage());
			driver.close();
		}
	}

	@AfterClass
	public void closebrowser() throws Exception {
		Properties PathProperties = new Properties();
		PathProperties.load(pathStream);
		try {
			String TestOP = PathProperties.getProperty("ReportPath");
		//	URI uri = new URI("E:/TestCode/Auto_Test_FrameWork/test-output/index.html");
			URI uri = new URI(TestOP.toString());
			Desktop.getDesktop().browse(uri);
		} catch (Exception e) {
			logger.info("\n\n" + e.getMessage());
		}
		Properties EmailProperties = new Properties();
		EmailProperties.load(emailStream);
		String host = "smtp.gmail.com";
		String port = "587";
		String mailFrom = EmailProperties.getProperty("mailFrom");
		String password = EmailProperties.getProperty("password");

		// message info
		String mailTo = EmailProperties.getProperty("mailTo");
		String subject = EmailProperties.getProperty("Subject");
		String message = EmailProperties.getProperty("Msg");

		// attachments
		String[] attachFiles = new String[2];
		attachFiles[0] = PathProperties.getProperty("ReportPath");
		attachFiles[1] = PathProperties.getProperty("EmailableReport");
		AmazonTestChrome.captureScreenshot(driver);

		try {
			EmailAttachmentSender.sendEmailWithAttachments(host, port, mailFrom, password, mailTo, subject, message,
					attachFiles);
			logger.info("\n\n Email Sent");
		} catch (Exception ex) {
			logger.info("\n\n Email send Fail");
			logger.info("\n\n" + ex.getMessage());
			ex.printStackTrace();
		}
		driver.close();
	}

}
