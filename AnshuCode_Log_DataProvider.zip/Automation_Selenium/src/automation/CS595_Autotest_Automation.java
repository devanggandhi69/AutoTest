package automation;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.AfterTest;
import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Method;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.util.Properties;

public class CS595_Autotest_Automation {
	public Logger logger = Logger.getLogger(CS595_Autotest_Automation.class);

	public static String[][] getExcelData() throws Exception {
		String[][] arrayExcelData = null;
	
		try {
			
			String FilePath = "C:\\NPU Studies\\CS595\\DataProvider.xlsx";
			// Open the Excel file
			FileInputStream ExcelFile = new FileInputStream(FilePath);
			System.out.println("File Path" + FilePath);
			// Access the required test data sheet
			XSSFWorkbook ExcelWBook = new XSSFWorkbook(ExcelFile);
			XSSFSheet Sheet1 = ExcelWBook.getSheetAt(0);
			int totalNoOfRows = Sheet1.getLastRowNum();
			int totalNoOfCols = 2;
			arrayExcelData = new String[totalNoOfRows][totalNoOfCols];
			for (int i = 1; i <= totalNoOfRows; i++) {
				for (int j = 0; j < totalNoOfCols; j++) {
					arrayExcelData[i][j] = Sheet1.getRow(i).getCell(j).getStringCellValue();
					//System.out.println("Values from excel:" + arrayExcelData[i][j]);
				}
			}
			ExcelWBook.close();
			return arrayExcelData;

		} catch (Exception e) {
			throw (e);
		}
	}
	@DataProvider(name = "excelData")
	public Object[][] loginData() throws Exception {
		// String[] values=getExcelData();
		Object[][] arrayObject = getExcelData();
		return arrayObject;
	}
	@Test(dataProvider = "data")
	public void tc_1_automated(String keyword) {
		ProfilesIni profile = new ProfilesIni();
		FirefoxProfile ffprofile = profile.getProfile("default");
		ffprofile.setEnableNativeEvents(true);
		WebDriver driver = new FirefoxDriver(ffprofile);
		String baseURl="https://www.amazon.com/";
		//System.out.print("baseURl");
		driver.get(baseURl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys(keyword);
		driver.findElement(By.xpath(".//*[@id='nav-search']/form/div[2]/div/input")).click();
		String ActualValue = driver.findElement(By.cssSelector(".a-color-state.a-text-bold")).getText();
		String expectedValue = keyword;
		ActualValue = ActualValue.replace("\"", "");
		
		Assert.assertTrue(expectedValue.equals(ActualValue), "Values matched");
		logger.info("Asserting first test case here");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.quit();
	}

	
	@DataProvider(name = "data")
	public static Object[][] getData(Method name) {
		Object[][] obj = null;
		;
		if (name.getName().equalsIgnoreCase("tc_1_automated")) {
			obj = new Object[3][1];

			obj[0][0] = "ipad";
			obj[1][0] = "amazon echo";
			obj[2][0] = "apple watch";
		}

		if (name.getName().equalsIgnoreCase("tc_2_automated")) {
			obj = new Object[1][1];
			obj[0][0] = "Dell laptops";
		}
		return obj;
	}

	@Test(dataProvider = "data")
	public void tc_2_automated(String keyword) {
		ProfilesIni profile = new ProfilesIni();
		FirefoxProfile ffprofile = profile.getProfile("default");
		ffprofile.setEnableNativeEvents(true);
		WebDriver driver = new FirefoxDriver(ffprofile);
		String baseURl="https://www.amazon.com/";
		driver.get(baseURl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys(keyword);
		driver.findElement(By.xpath(".//*[@id='nav-search']/form/div[2]/div/input")).click();
		List<WebElement> search = driver
				.findElements(By.xpath(".//*[@id='result_0']/div/div/div/div[2]/div[3]/div[1]/a/h2"));
		String ActualValue = search.get(0).getText();
		System.out.println("Actual value:" + ActualValue);
		
		search.get(0).click();
		// System.out.print("The size is"+ search.size());
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,1000)", "");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		String expectedValue = driver.findElement(By.xpath(".//*[@id='title']")).getText();
		System.out.println("Expected value:" + expectedValue);
		logger.info("Asserting second test case here");
		Assert.assertTrue(expectedValue.equals(ActualValue), "Values matched");
		driver.quit();
	}

	@org.testng.annotations.BeforeClass
	public void BeforeClass() {

		logger.info("******--This is before class method--******");

	}

	@AfterClass
	public void afterClass() {
		logger.info("******--This is after class method--******");
	}

}
